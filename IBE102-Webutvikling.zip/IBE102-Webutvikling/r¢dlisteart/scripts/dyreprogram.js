const myImage = document.querySelector("img");

myImage.onclick = () => {
    const mySrc = myImage.getAttribute("src");
    if (mySrc === "images/250px-Somateria_mollissima_male_female.jpg") {
        myImage.setAttribute("src", "images/250px-E-unger.jpg");
    } else {
        myImage.setAttribute("src", "images/250px-Somateria_mollissima_male_female.jpg");
    }
};