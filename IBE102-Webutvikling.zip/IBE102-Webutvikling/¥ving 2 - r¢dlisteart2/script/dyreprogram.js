const myImage = document.querySelector("img");

myImage.onclick = () => {
    const mySrc = myImage.getAttribute("src");
    if (mySrc === "bilder/250px-Somateria_mollissima_male_female.jpg") {
        myImage.setAttribute("src", "bilder/250px-E-unger.jpg");
    } else if (mySrc === "bilder/250px-E-unger.jpg") {
        myImage.setAttribute("src", "bilder/Somateria_mollissima_MHNT.ZOO.2010.11.26.1.jpg");
    } else {
        myImage.setAttribute("src", "bilder/250px-Somateria_mollissima_male_female.jpg");
    }
};