const myHeading = document.querySelector("h1");
myHeading.textContent = "Eksempel på rødlisteart";

let antall = 0

document.querySelector("h1").addEventListener("click", function () {
    antall++
    alert(`Au! Du har trykket meg ${antall} antall ganger`);
    });


document.querySelector("button").addEventListener("click", function () {
    alert("Dette er et nettsted som handler om ..., og det er laget av ...");
    });